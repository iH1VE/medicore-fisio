<?php
require __DIR__ . '/_common.php';

ensure_table($conn, "CREATE TABLE IF NOT EXISTS appointments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  external_id VARCHAR(64) NOT NULL UNIQUE,
  paciente_id VARCHAR(64) DEFAULT NULL,
  paciente_nome VARCHAR(255) DEFAULT NULL,
  data_consulta DATE DEFAULT NULL,
  hora_consulta TIME DEFAULT NULL,
  status VARCHAR(50) DEFAULT NULL,
  valor DECIMAL(12,2) DEFAULT NULL,
  payload_json LONGTEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'GET') {
    $res = $conn->query("SELECT external_id, payload_json FROM appointments ORDER BY data_consulta DESC, hora_consulta DESC, id DESC");
    respond_json(['ok' => true, 'items' => $res ? map_rows($res) : []]);
}
if ($method === 'POST') {
    $data = json_input();
    if (!$data) respond_json(['ok' => false, 'error' => 'Payload vazio'], 400);
    $externalId = get_external_id($data);
    $payloadJson = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $pacienteId = $data['pacienteId'] ?? null;
    $pacienteNome = $data['pacienteNome'] ?? null;
    $dataConsulta = !empty($data['data']) ? date('Y-m-d', strtotime($data['data'])) : null;
    $horaConsulta = !empty($data['hora']) ? date('H:i:s', strtotime($data['hora'])) : null;
    $status = $data['status'] ?? null;
    $valor = isset($data['valor']) ? (float)$data['valor'] : null;

    $stmt = $conn->prepare("INSERT INTO appointments (external_id, paciente_id, paciente_nome, data_consulta, hora_consulta, status, valor, payload_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE paciente_id=VALUES(paciente_id), paciente_nome=VALUES(paciente_nome), data_consulta=VALUES(data_consulta), hora_consulta=VALUES(hora_consulta), status=VALUES(status), valor=VALUES(valor), payload_json=VALUES(payload_json)");
    $stmt->bind_param('ssssssds', $externalId, $pacienteId, $pacienteNome, $dataConsulta, $horaConsulta, $status, $valor, $payloadJson);
    $stmt->execute();
    respond_json(['ok' => true, 'id' => $externalId]);
}
if ($method === 'DELETE') {
    $id = $_GET['id'] ?? '';
    if ($id === '') respond_json(['ok' => false, 'error' => 'ID obrigatório'], 400);
    $stmt = $conn->prepare("DELETE FROM appointments WHERE external_id=?");
    $stmt->bind_param('s', $id);
    $stmt->execute();
    respond_json(['ok' => true]);
}
respond_json(['ok' => false, 'error' => 'Método não permitido'], 405);
