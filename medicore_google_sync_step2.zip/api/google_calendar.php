<?php
require_once __DIR__ . '/vendor/autoload.php';

$client = new Google_Client();
$client->setAuthConfig('/var/www/keys/google.json');
$client->addScope(Google_Service_Calendar::CALENDAR);

$service = new Google_Service_Calendar($client);

$calendarId = 'ab8dae5cc0ae67d5d51e2df47ca8f4053ca2cd10ff56e80109a3c9991fbb4ae9@group.calendar.google.com';

$data = json_decode(file_get_contents("php://input"), true);

$event = new Google_Service_Calendar_Event([
    'summary' => $data['titulo'] ?? 'Consulta MediCore',
    'description' => $data['descricao'] ?? '',
    'start' => [
        'dateTime' => $data['inicio'],
        'timeZone' => 'America/Sao_Paulo',
    ],
    'end' => [
        'dateTime' => $data['fim'],
        'timeZone' => 'America/Sao_Paulo',
    ],
]);

try {
    $event = $service->events->insert($calendarId, $event);

    echo json_encode([
        "ok" => true,
        "event_id" => $event->id
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "ok" => false,
        "error" => $e->getMessage()
    ]);
}
