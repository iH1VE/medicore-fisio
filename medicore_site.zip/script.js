'use strict';

// ============================================
// UTILS
// ============================================
const generateId = () => Math.random().toString(36).substr(2, 9);
const formatDate = (dateString) => { 
    if(!dateString) return ''; 
    const parts = dateString.split('-'); 
    if(parts.length===3) return `${parts[2]}/${parts[1]}/${parts[0]}`; 
    return dateString; 
};
const formatCurrency = (val) => new Intl.NumberFormat('pt-BR', { 
    style: 'currency', 
    currency: 'BRL' 
}).format(val || 0);

const getTodayISO = () => new Date().toISOString().split('T')[0];
const getYearFromDate = (dateString) => {
    const d = new Date(dateString);
    return Number.isNaN(d.getTime()) ? new Date().getFullYear() : d.getFullYear();
};
const getMonthFromDate = (dateString) => {
    const d = new Date(dateString);
    return Number.isNaN(d.getTime()) ? 0 : d.getMonth();
};

function buildFinancialEntries() {
    const persisted = (DB.financeiro || []).map(f => ({
        ...f,
        origem: f.origem || (f.valor >= 0 ? 'Receita' : 'Despesa'),
        categoria: f.categoria || (f.valor >= 0 ? 'receita' : 'despesa')
    }));

    const existingStockIds = new Set(
        persisted
            .filter(f => f.categoria === 'despesa_estoque' && f.estoqueItemId)
            .map(f => f.estoqueItemId)
    );

    const legacyStockExpenses = (DB.estoque || [])
        .filter(item => item && !existingStockIds.has(item.id))
        .map(item => ({
            id: `stock_${item.id}`,
            data: item.dataEntrada || item.dataCompra || getTodayISO(),
            pacienteId: null,
            pacienteNome: 'Estoque',
            tipo: 'Compra de estoque',
            valor: -Math.abs((Number(item.qtd) || 0) * (Number(item.custo) || 0)),
            metodo: 'Custo interno',
            parcelas: 1,
            origem: 'Estoque',
            categoria: 'despesa_estoque',
            estoqueItemId: item.id,
            detalhes: { item: item.nome, lote: item.lote || 'N/A' }
        }))
        .filter(item => item.valor !== 0);

    return [...persisted, ...legacyStockExpenses]
        .sort((a, b) => new Date(b.data) - new Date(a.data));
}


// ============================================
// STATE
// ============================================
let currentUserRole = null;
let calendarDate = new Date();
let currentConsultationId = null;
let currentQuickPatientId = null;
let tempPrescription = [];
let tempExams = [];
let tempAnamnese = null;
let financeChart = null;
let patientsChart = null;
let financialFilterMode = 'month';
let financialFilterYear = new Date().getFullYear();
let financialFilterMonth = new Date().getMonth();

let DB = { 
    pacientes: [], 
    agendamentos: [], 
    estoque: [], 
    auditoria: [], 
    atendimentos: [], 
    catalogoExames: [], 
    financeiro: [], 
    protocolos: [], 
    contratos: [], 
    avaliacoes: [] 
};

// ============================================
// INITIAL DATA
// ============================================
const initialData = {
    pacientes: [
        { id: '1', nome: 'João Silva', cpf: '123.456.789-00', tel: '(11) 98765-4321', lgpdConsent: true, dataCadastro: '2021-05-10', dataNascimento: '1985-05-20', endereco: 'Rua A', tipoAtendimento: 'Particular' },
        { id: '2', nome: 'Maria Oliveira', cpf: '234.567.890-11', tel: '(21) 99876-5432', lgpdConsent: true, dataCadastro: '2021-08-20', dataNascimento: '1990-08-15', endereco: 'Av B', tipoAtendimento: 'Convênio' },
        { id: '3', nome: 'Carlos Pereira', cpf: '345.678.901-22', tel: '(11) 91234-5678', lgpdConsent: true, dataCadastro: '2022-02-11', dataNascimento: '1978-03-10', endereco: 'Rua C', tipoAtendimento: 'Particular' },
        { id: '4', nome: 'Ana Santos', cpf: '456.789.012-33', tel: '(21) 93456-7890', lgpdConsent: true, dataCadastro: '2022-05-03', dataNascimento: '1988-11-02', endereco: 'Av D', tipoAtendimento: 'Convênio' },
        { id: '5', nome: 'Marcos Lima', cpf: '567.890.123-44', tel: '(31) 95555-4444', lgpdConsent: true, dataCadastro: '2023-01-20', dataNascimento: '1992-07-15', endereco: 'Rua E', tipoAtendimento: 'Particular' },
        { id: '6', nome: 'Patrícia Costa', cpf: '678.901.234-55', tel: '(41) 96666-3333', lgpdConsent: true, dataCadastro: '2023-03-12', dataNascimento: '1995-12-05', endereco: 'Av F', tipoAtendimento: 'Particular' },
        { id: '7', nome: 'Rafael Gomes', cpf: '789.012.345-66', tel: '(51) 97777-2222', lgpdConsent: true, dataCadastro: '2023-06-30', dataNascimento: '1982-09-09', endereco: 'Rua G', tipoAtendimento: 'Convênio' },
        { id: '8', nome: 'Sofia Almeida', cpf: '890.123.456-77', tel: '(61) 98888-1111', lgpdConsent: true, dataCadastro: '2024-01-05', dataNascimento: '2000-04-22', endereco: 'Av H', tipoAtendimento: 'Particular' },
        { id: '9', nome: 'Felipe Rocha', cpf: '901.234.567-88', tel: '(71) 99999-0000', lgpdConsent: true, dataCadastro: '2024-07-19', dataNascimento: '1975-06-30', endereco: 'Rua I', tipoAtendimento: 'Particular' },
        { id: '10', nome: 'Bruna Ferreira', cpf: '012.345.678-99', tel: '(81) 98877-6655', lgpdConsent: true, dataCadastro: '2024-10-11', dataNascimento: '1998-02-18', endereco: 'Av J', tipoAtendimento: 'Convênio' }
    ],
    protocolos: [
        { id: 'p1', nome: 'Emagrecimento 60 Dias', valor: 2500.00, duracao: 60, servicos: { 'Consulta': 2, 'Nutricionista': 2, 'Exame': 1, 'Procedimento': 4 } },
        { id: 'p2', nome: 'Fisioterapia Intensiva', valor: 1200.00, duracao: 30, servicos: { 'Procedimento': 10, 'Consulta': 1 } },
        { id: 'p3', nome: 'Reabilitação Pós-Cirúrgica', valor: 1800.00, duracao: 45, servicos: { 'Consulta': 3, 'Procedimento': 8 } },
        { id: 'p4', nome: 'Antiaging - 12 Semanas', valor: 3200.00, duracao: 84, servicos: { 'Consulta': 4, 'Procedimento': 10, 'Exame': 2 } },
        { id: 'p5', nome: 'Checkup Preventivo', valor: 450.00, duracao: 1, servicos: { 'Consulta': 1, 'Exame': 3 } },
        { id: 'p6', nome: 'Controle de Dor Crônica', valor: 900.00, duracao: 30, servicos: { 'Consulta': 2, 'Procedimento': 6 } },
        { id: 'p7', nome: 'Estética Facial Básica', valor: 650.00, duracao: 21, servicos: { 'Consulta': 1, 'Procedimento': 3 } }
    ],
    estoque: [
        { id: 'e1', nome: 'Dipirona 500mg', lote: 'L100', validade: '2025-12-01', qtd: 50, min: 20, preco: 2.50, custo: 0.50 },
        { id: 'e4', nome: 'Seringa 5ml', lote: 'S500', validade: '2026-01-01', qtd: 100, min: 50, preco: 5.00, custo: 1.00 }
    ],
    catalogoExames: [
        { id: 'ex1', nome: 'Hemograma Completo', preco: 35.00 },
        { id: 'ex4', nome: 'Raio-X de Tórax', preco: 90.00 }
    ],
    financeiro: [
        { id: 'f23_5', data: '2023-12-20', pacienteId: '1', pacienteNome: 'João Silva', tipo: 'Consulta', valor: 250.00, metodo: 'Cartão', parcelas: 1, detalhes: { medicamentos: 0 } },
        { id: 'f_sim_1', data: '2026-01-15', pacienteId: '3', pacienteNome: 'Carlos Pereira', tipo: 'Consulta', valor: 150.00, metodo: 'Pix', parcelas: 1 }
    ],
    atendimentos: [
        { id: 'at1', agendamentoId: 'old1', pacienteId: '1', data: '2023-12-20', prescricao: [], exames: [], anamnese: { "5": "Dor de cabeça persistente." } },
        { id: 'at_sim_1', agendamentoId: 'ag_sim_old', pacienteId: '4', data: '2025-11-02', prescricao: [], exames: [], anamnese: { note: 'Histórico: recuperação parcial.' } }
    ],
    agendamentos: [
        { id: 'ag_past_1', pacienteId: '1', pacienteNome: 'João Silva', data: '2025-12-20', hora: '10:00', motivo: 'Retorno', tipo: 'Retorno', valor: 150.00, prioridade: 'Normal', status: 'Finalizado' }
    ],
    auditoria: []
};

// Perguntas padrão para Anamnese
const STANDARD_QUESTIONS = [
    'Queixa principal (motivo da consulta)',
    'Início dos sintomas (data/tempo)',
    'Localização da dor / sintoma',
    'Intensidade (0-10)',
    'Fatores que agravam',
    'Fatores que aliviam',
    'Sintomas associados',
    'Histórico médico pregresso',
    'Uso de medicação atual',
    'Alergias conhecidas',
    'Cirurgias prévias relevantes',
    'Doenças crônicas (hipertensão, diabetes etc.)',
    'Tabagismo / etilismo',
    'Atividade física / rotina',
    'Sono / padrão alimentar',
    'Eventos familiares relevantes',
    'Tratamentos anteriores para o problema',
    'Expectativas do paciente',
    'Observações sobre mobilidade / função',
    'Outras observações clínicas'
];

// Flag de simulação
const SIMULATE_TESTS = true;

// ============================================
// SERVER DB (MariaDB via PHP API)
// ============================================
const API_STATE_URL = 'api/state.php';
let USING_SERVER_DB = false;

async function apiGetState() {
    try {
        const res = await fetch(API_STATE_URL, { cache: 'no-store' });
        if (!res.ok) return null;
        return await res.json();
    } catch (e) {
        return null;
    }
}

async function apiSaveState(payload) {
    try {
        const res = await fetch(API_STATE_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        return res.ok;
    } catch (e) {
        return false;
    }
}



// ============================================
// CORE FUNCTIONS
// ============================================

function checkAlerts() {
    const alertsList = document.getElementById('alerts-list');
    const badge = document.getElementById('alert-badge');
    const alertBox = document.getElementById('dashboard-alerts');
    let count = 0; 
    let html = '';
    
    if (!DB.estoque) return;
    
    DB.estoque.forEach(e => {
        const today = new Date(); 
        const valDate = new Date(e.validade);
        if (valDate < today) { 
            count++; 
            html += `<div class="flex items-center gap-2"><i class="fa-solid fa-triangle-exclamation text-[#6F4B36]"></i><span>Item <b>${e.nome}</b> (Lote ${e.lote}) está <span class="font-bold text-[#6F4B36]">VENCIDO</span>.</span></div>`; 
        } else if (e.qtd <= e.min) { 
            count++; 
            html += `<div class="flex items-center gap-2"><i class="fa-solid fa-circle-exclamation text-[#6F4B36]"></i><span>Item <b>${e.nome}</b> está com estoque <span class="font-bold text-[#6F4B36]">BAIXO</span> (${e.qtd} unidades).</span></div>`; 
        }
    });
    
    if (count > 0 && badge && alertBox && alertsList) {
        badge.innerText = count; 
        badge.classList.remove('hidden'); 
        alertsList.innerHTML = html; 
        alertBox.classList.remove('hidden');
    } else if (badge && alertBox) {
        badge.classList.add('hidden'); 
        alertBox.classList.add('hidden');
    }
}

async function loadDB() {
    // 1) tenta carregar do servidor (MariaDB via API)
    const serverData = await apiGetState();
    if (serverData && typeof serverData === 'object') {
        DB = { ...initialData, ...serverData };
        if (!DB.protocolos) DB.protocolos = initialData.protocolos;
        if (!DB.avaliacoes) DB.avaliacoes = [];
        USING_SERVER_DB = true;

        // opcional: manter cópia local como fallback
        localStorage.setItem('sgc_db', JSON.stringify(DB));
        checkAlerts();
        return;
    }

    // 2) fallback local (como já era)
    USING_SERVER_DB = false;
    const saved = localStorage.getItem('sgc_db');
    if (saved) {
        try {
            const parsed = JSON.parse(saved);
            DB = { ...initialData, ...parsed };
            if (!DB.protocolos) DB.protocolos = initialData.protocolos;
        } catch(e) {
            DB = JSON.parse(JSON.stringify(initialData));
            localStorage.setItem('sgc_db', JSON.stringify(DB));
        }
    } else {
        DB = JSON.parse(JSON.stringify(initialData));
        localStorage.setItem('sgc_db', JSON.stringify(DB));
    }

    if(!DB.avaliacoes) DB.avaliacoes = [];
    checkAlerts();
}

function saveDB() {
    // sempre salva local (backup + mantém funcional sem servidor)
    localStorage.setItem('sgc_db', JSON.stringify(DB));
    checkAlerts();

    // se estiver usando servidor, salva também no banco (assíncrono)
    if (USING_SERVER_DB) {
        apiSaveState(DB).then(ok => {
            if (!ok) console.warn('Falha ao salvar no servidor; usando localStorage como fallback.');
        });
    }
}

function logAudit(acao, detalhes) { 
    DB.auditoria.unshift({ 
        id: generateId(), 
        timestamp: new Date().toISOString(), 
        usuario: DB.currentUser || 'Sistema', 
        acao, 
        detalhes: JSON.stringify(detalhes) 
    }); 
    saveDB(); 
}

function showToast(msg, type='success') { 
    const t = document.getElementById('toast-notification'); 
    if(!t) return; 
    
    const icon = type === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check';
    t.innerHTML = `<i class="fa-solid ${icon} mr-2"></i><span>${msg}</span>`;
    t.className = `fixed bottom-6 right-6 text-white px-6 py-4 rounded-2xl shadow-xl z-50 toast-animate ${type==='error' ? 'bg-red-600' : 'bg-[#6F4B36]'}`; 
    t.classList.remove('hidden'); 
    setTimeout(() => t.classList.add('hidden'), 3000); 
}

// ============================================
// NAVIGATION
// ============================================

function login(role) {
    currentUserRole = role; 
    DB.currentUser = role === 'ADMIN' ? 'Administrador' : 'Funcionário';
    
    document.getElementById('modal-login').classList.add('hidden');
    document.getElementById('header-username').innerHTML = `<i class="fa-regular fa-user mr-2"></i>${DB.currentUser}`;
    document.getElementById('user-role-badge').innerHTML = role === 'ADMIN' ? 'Administrador' : 'Funcionário';
    
    showSection('dashboard'); 
    updateDashboard();
    initVisualEnhancements();
}

function logout() { 
    location.reload(); 
}

function showSection(id) {
    if (currentUserRole === 'FUNCIONARIO' && (id === 'financeiro' || id === 'auditoria' || id === 'estrategia' || id === 'protocolos')) { 
        showToast('Acesso restrito para funcionários', 'error'); 
        return; 
    }
    
    document.querySelectorAll('main > section').forEach(s => s.classList.add('hidden'));
    document.getElementById(id).classList.remove('hidden');
    
    // Atualizar conteúdo baseado na seção
    if(id === 'dashboard') updateDashboard();
    if(id === 'estrategia') setTimeout(renderStrategySection, 80);
    if(id === 'protocolos') renderProtocolos();
    if(id === 'estoque') renderEstoque();
    if(id === 'auditoria') renderAuditoria();
    if(id === 'atendimento') renderAtendimentoScreen();
    if(id === 'pacientes') renderPacientes();
    if(id === 'agenda') renderCalendar();
    if(id === 'financeiro') setTimeout(renderFinancialReport, 30);
    if(id === 'relatorios') renderRelatorios();
    
    document.getElementById('page-title').innerText = getSectionTitle(id);
    
    // Aplicar melhorias visuais
    setTimeout(initVisualEnhancements, 50);
}

function getSectionTitle(id) {
    const titles = {
        'dashboard': 'Dashboard',
        'estrategia': 'Estratégia',
        'protocolos': 'Protocolos',
        'pacientes': 'Pacientes',
        'agenda': 'Agenda',
        'atendimento': 'Atendimento',
        'estoque': 'Estoque',
        'financeiro': 'Financeiro',
        'relatorios': 'Relatórios',
        'auditoria': 'Auditoria'
    };
    return titles[id] || id.charAt(0).toUpperCase() + id.slice(1);
}

// ============================================
// MODALS
// ============================================

function openModal(id, date = null) { 
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.remove('hidden');
        
        if(id==='modal-agendamento') { 
            populatePatientSelect(); 
            if(date) document.getElementById('ag-data').value = date; 
        }
        if(id==='modal-paciente') { 
            document.getElementById('form-paciente').reset(); 
            document.getElementById('pac-id').value = ''; 
            const title = document.getElementById('modal-paciente-title');
            const submitBtn = document.querySelector('#form-paciente button[type="submit"]');
            if (title) title.innerText = 'Novo Paciente';
            if (submitBtn) submitBtn.innerText = 'Salvar Paciente';
        }
        if(id==='modal-novo-protocolo') {
            const form = document.getElementById('form-novo-protocolo');
            form.reset();
            delete form.dataset.editingId;
            document.getElementById('prot-dias').value = 30;
            document.getElementById('prot-cred-consulta').value = 0;
            document.getElementById('prot-cred-nutri').value = 0;
            document.getElementById('prot-cred-exame').value = 0;
            document.getElementById('prot-cred-proced').value = 0;
            const title = document.querySelector('#modal-novo-protocolo h3');
            const submitBtn = document.querySelector('#form-novo-protocolo button[type="submit"]');
            if (title) title.innerText = 'Novo Protocolo';
            if (submitBtn) submitBtn.innerText = 'Salvar Protocolo';
        }
    }
}

function closeModal(id) { 
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.add('hidden'); 
    }
}

function resetSystem() { 
    if(confirm("Tem certeza que deseja apagar todos os dados do sistema?")) { 
        localStorage.removeItem('sgc_db'); 
        location.reload(); 
    } 
}

// ============================================
// RENDERERS
// ============================================

function updateDashboard() {
    document.getElementById('kpi-total-patients').innerText = DB.pacientes.length;
    
    const today = new Date().toLocaleDateString('fr-CA');
    document.getElementById('kpi-today-appts').innerText = DB.agendamentos.filter(a => a.data === today).length;
    document.getElementById('kpi-sales').innerText = formatCurrency(DB.financeiro.reduce((s,f)=>s+f.valor,0));
    
    // Pacientes inativos
    const limit = new Date(); 
    limit.setMonth(limit.getMonth()-3);
    const inactive = DB.pacientes.filter(p => {
        const visits = DB.atendimentos.filter(a => a.pacienteId === p.id);
        let last = visits.length > 0 ? new Date(visits.sort((a,b)=>new Date(b.data)-new Date(a.data))[0].data) : new Date(p.dataCadastro);
        return last < limit;
    });
    
    document.getElementById('inactive-count').innerText = `${inactive.length} encontrados`;
    document.getElementById('table-inactive-patients').innerHTML = inactive.map(p => {
        const lastVisit = DB.atendimentos.filter(a => a.pacienteId === p.id)
            .sort((a,b)=>new Date(b.data)-new Date(a.data))[0];
        const daysInactive = lastVisit ? Math.floor((new Date() - new Date(lastVisit.data)) / (1000*60*60*24)) : 'N/A';
        
        return `<tr class="hover:bg-[#FCF7F9] transition-colors">
            <td class="p-3 font-medium text-gray-800">${p.nome}</td>
            <td class="p-3 text-gray-600">${p.tel || '—'}</td>
            <td class="p-3 text-gray-600">${lastVisit ? formatDate(lastVisit.data) : 'Nunca'}</td>
            <td class="p-3 text-center"><span class="badge badge-secondary">${daysInactive} dias</span></td>
            <td class="p-3 text-center">
                <button onclick="openModal('modal-agendamento', '${today}')" class="btn-primary text-xs !py-1.5 !px-3">
                    <i class="fa-solid fa-calendar-plus mr-1"></i>Agendar
                </button>
            </td>
        </tr>`;
    }).join('');
}

function renderProtocolos() {
    document.getElementById('table-protocolos-body').innerHTML = (DB.protocolos||[]).map(p => `
        <tr class="hover:bg-[#FCF7F9] transition-colors">
            <td class="p-3 font-bold text-[#6F4B36]">${p.nome}</td>
            <td class="p-3 text-sm text-gray-600">
                ${Object.entries(p.servicos || {}).map(([k,v]) => `<span class="badge badge-secondary mr-1 mb-1">${v}x ${k}</span>`).join('')}
            </td>
            <td class="p-3 text-right font-mono font-bold text-[#6F4B36]">${formatCurrency(p.valor)}</td>
            <td class="p-3 text-center text-gray-600">${p.duracao} dias</td>
            <td class="p-3 text-center">
                <button class="text-[#6F4B36] hover:text-[#5A3C2B] transition-colors mx-1" onclick="editProtocol('${p.id}')">
                    <i class="fa-solid fa-edit"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function renderPacientes() {
    const s = document.getElementById('search-paciente').value.toLowerCase();
    document.getElementById('table-pacientes-body').innerHTML = DB.pacientes
        .filter(p => (p.nome||'').toLowerCase().includes(s) || (p.cpf||'').includes(s))
        .map(p => `
        <tr class="hover:bg-[#FCF7F9] transition-colors">
            <td class="p-3 font-medium text-gray-800">${p.nome}</td>
            <td class="p-3 text-gray-600">${p.cpf}</td>
            <td class="p-3 text-gray-600">${p.dataNascimento ? formatDate(p.dataNascimento) : '—'}</td>
            <td class="p-3"><span class="badge ${p.tipoAtendimento === 'Particular' ? 'badge-primary' : 'badge-secondary'}">${p.tipoAtendimento}</span></td>
            <td class="p-3 text-center text-gray-600">${p.dataCadastro ? formatDate(p.dataCadastro.split('T')[0]) : '—'}</td>
            <td class="p-3 text-center">
                <button onclick="editPatient('${p.id}')" class="text-[#6F4B36] hover:text-[#5A3C2B] transition-colors mx-1" title="Editar">
                    <i class="fa-solid fa-pen"></i>
                </button>
                <button onclick="openPatientReport('${p.id}')" class="text-[#6F4B36] hover:text-[#5A3C2B] transition-colors mx-1" title="Prontuário">
                    <i class="fa-solid fa-file-medical"></i>
                </button>
                <button onclick="renderPatientQuickReport('${p.id}')" class="text-[#6F4B36] hover:text-[#5A3C2B] transition-colors mx-1" title="Resumo Rápido">
                    <i class="fa-solid fa-circle-info"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function renderCalendar() {
    const grid = document.getElementById('calendar-grid'); 
    grid.innerHTML = '';
    
    const monthNames = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
    document.getElementById('calendar-month-year').innerHTML = `${monthNames[calendarDate.getMonth()]} <span class="text-gray-500 font-light">${calendarDate.getFullYear()}</span>`;
    
    const year = calendarDate.getFullYear(), 
          month = calendarDate.getMonth();
    const firstDay = new Date(year, month, 1).getDay(), 
          daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = new Date().toLocaleDateString('fr-CA');
    
    // Ajustar primeiro dia (no Brasil, domingo é 0)
    const adjustedFirstDay = firstDay === 0 ? 6 : firstDay - 1;
    
    for (let i = 0; i < adjustedFirstDay; i++) {
        grid.innerHTML += `<div class="calendar-cell other-month"></div>`;
    }
    
    for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const isToday = dateStr === today;
        const events = DB.agendamentos.filter(a => a.data === dateStr && a.status !== 'Finalizado');
        
        let html = events.map(ev => {
            let cls = ev.status === 'Em Atendimento' ? 'bg-[#CBE5F7] text-[#2D3E50]' : 'bg-[#FCF7F9] text-[#6F4B36] border border-[#CBE5F7]';
            if(ev.prioridade === 'Emergência') cls = 'bg-red-100 text-red-900 border-red-200';
            if(ev.prioridade === 'Urgência') cls = 'bg-orange-100 text-orange-900 border-orange-200';
            
            return `<div onclick="event.stopPropagation(); checkIn('${ev.id}')" class="calendar-event ${cls}">
                <span class="font-bold">${ev.hora}</span> ${ev.pacienteNome}
            </div>`;
        }).join('');
        
        grid.innerHTML += `<div class="calendar-cell ${isToday ? 'is-today' : ''}" onclick="openModal('modal-agendamento', '${dateStr}')">
            <div class="calendar-day-num">${day}</div>
            <div class="flex flex-col gap-1.5 mt-2">${html}</div>
        </div>`;
    }
    
    const waiting = DB.agendamentos.filter(a => a.status === 'Aguardando')
        .sort((a,b) => a.hora.localeCompare(b.hora));
    
    document.getElementById('fila-espera-list').innerHTML = waiting.length > 0 
        ? waiting.map(ag => `
            <div onclick="showSection('atendimento'); startConsultation('${ag.id}')" 
                 class="bg-white border-2 border-[#CBE5F7] hover:border-[#6F4B36] p-4 rounded-2xl shadow-sm cursor-pointer min-w-[220px] transition-all hover:shadow-md">
                <div class="flex items-center gap-3">
                    <div class="w-8 h-8 bg-[#FCF7F9] rounded-full flex items-center justify-center">
                        <i class="fa-solid fa-user-clock text-[#6F4B36]"></i>
                    </div>
                    <div>
                        <div class="font-bold text-gray-800">${ag.pacienteNome}</div>
                        <div class="text-xs text-gray-500">${ag.hora} • ${ag.prioridade}</div>
                    </div>
                </div>
            </div>
        `).join('')
        : '<div class="text-gray-400 text-sm py-4">Nenhum paciente aguardando</div>';
}

function changeMonth(step) { 
    calendarDate.setMonth(calendarDate.getMonth() + step); 
    renderCalendar(); 
}

function goToToday() { 
    calendarDate = new Date(); 
    renderCalendar(); 
}

function checkIn(id) { 
    const ag = DB.agendamentos.find(a => a.id === id); 
    if(ag && ag.status === 'Agendado') { 
        ag.status = 'Aguardando'; 
        saveDB(); 
        renderCalendar(); 
        showToast(`Check-in realizado: ${ag.pacienteNome}`); 
    } 
}

function renderAtendimentoScreen() {
    const today = new Date().toLocaleDateString('fr-CA');
    const list = DB.agendamentos.filter(a => a.data === today && a.status !== 'Finalizado')
        .sort((a,b) => {
            if(a.status === 'Em Atendimento') return -1;
            if(b.status === 'Em Atendimento') return 1;
            return a.hora.localeCompare(b.hora);
        });
    
    document.getElementById('today-appointments-list').innerHTML = list.length > 0
        ? list.map(a => `
            <div onclick="startConsultation('${a.id}')" 
                 class="p-4 border-2 rounded-2xl cursor-pointer transition-all hover:shadow-md
                        ${a.status === 'Em Atendimento' 
                            ? 'border-[#6F4B36] bg-[#FCF7F9]' 
                            : 'border-[#CBE5F7] hover:border-[#6F4B36] bg-white'}">
                <div class="flex items-center justify-between mb-2">
                    <div class="font-bold text-gray-800">${a.pacienteNome}</div>
                    <span class="badge ${a.prioridade === 'Emergência' ? 'badge-primary' : 'badge-secondary'} text-xs">
                        ${a.prioridade}
                    </span>
                </div>
                <div class="flex justify-between items-center">
                    <div class="text-sm text-gray-500">
                        <i class="fa-regular fa-clock mr-1"></i>${a.hora}
                    </div>
                    <div class="text-xs ${a.status === 'Em Atendimento' ? 'text-[#6F4B36] font-bold' : 'text-gray-400'}">
                        ${a.status === 'Em Atendimento' ? '⚡ Em atendimento' : '⏳ Aguardando'}
                    </div>
                </div>
            </div>
        `).join('')
        : '<div class="text-center py-8 text-gray-400 bg-[#FCF7F9] rounded-2xl">Nenhum atendimento agendado para hoje</div>';
    
    if(currentConsultationId) {
        const appt = DB.agendamentos.find(a => a.id === currentConsultationId);
        if (appt) {
            const p = DB.pacientes.find(x => x.id === appt.pacienteId);
            if (p) {
                document.getElementById('area-clinica-empty').classList.add('hidden');
                document.getElementById('area-clinica-active').classList.remove('hidden');
                document.getElementById('current-patient-name').innerText = appt.pacienteNome;
                document.getElementById('current-patient-cpf').innerText = p.cpf;
                document.getElementById('atendimento-tipo').innerHTML = `<i class="fa-regular fa-stethoscope mr-1"></i>${appt.tipo}`;
                document.getElementById('atendimento-valor').innerText = formatCurrency(appt.valor);
                
                // Badge de prioridade
                const priorityBadge = document.getElementById('atendimento-prioridade-badge');
                priorityBadge.innerText = appt.prioridade;
                priorityBadge.className = `badge ${appt.prioridade === 'Emergência' ? 'badge-primary' : 'badge-secondary'}`;
                
                // Populate selects
                const medSelect = document.getElementById('consult-medication');
                if(medSelect.options.length <= 1) {
                    medSelect.innerHTML = '<option value="">Selecione um medicamento...</option>' + 
                        DB.estoque.map(e => `<option value="${e.id}">${e.nome} - ${formatCurrency(e.preco)}</option>`).join('');
                }
                
                const examSelect = document.getElementById('consult-exam');
                if(examSelect.options.length <= 1) {
                    examSelect.innerHTML = '<option value="">Selecione um exame...</option>' + 
                        DB.catalogoExames.map(e => `<option value="${e.id}">${e.nome} - ${formatCurrency(e.preco)}</option>`).join('');
                }
                
                // Anamnese preview
                try {
                    const preview = document.getElementById('anamnese-preview');
                    const lastAnam = (DB.avaliacoes||[])
                        .filter(a => a.pacienteId === p.id)
                        .sort((a,b) => new Date(b.timestamp) - new Date(a.timestamp))[0];
                    
                    if(preview) {
                        if(lastAnam) {
                            preview.innerHTML = `
                                <div class="flex justify-between items-start">
                                    <div>
                                        <span class="font-bold text-[#6F4B36]">${new Date(lastAnam.timestamp).toLocaleString()}</span>
                                        <button class="ml-2 text-sm text-[#6F4B36] underline hover:no-underline" onclick="openAnamneseHistory('${p.id}')">
                                            Ver histórico
                                        </button>
                                    </div>
                                </div>
                                <div class="mt-2 text-gray-600">${(lastAnam.notes || '').slice(0, 200)}${(lastAnam.notes || '').length > 200 ? '...' : ''}</div>
                            `;
                        } else {
                            preview.innerHTML = '<span class="text-gray-400">Nenhum registro de anamnese encontrado.</span>';
                        }
                    }
                    
                    const histEl = document.getElementById('historico-recente-list');
                    if(histEl) {
                        const recent = (DB.avaliacoes||[])
                            .filter(a => a.pacienteId === p.id)
                            .sort((a,b) => new Date(b.timestamp) - new Date(a.timestamp))
                            .slice(0, 5);
                        
                        if(recent.length === 0) {
                            histEl.innerHTML = '<div class="text-sm text-gray-400 p-3 bg-[#FCF7F9] rounded-xl">Nenhum registro de anamnese.</div>';
                        } else {
                            histEl.innerHTML = recent.map(r => `
                                <div class="p-3 bg-[#FCF7F9] rounded-xl border border-[#CBE5F7] border-opacity-30 flex justify-between items-center">
                                    <div class="text-sm">
                                        <div class="font-medium text-gray-800">${new Date(r.timestamp).toLocaleString()}</div>
                                        <div class="text-xs text-gray-500 mt-1">${(r.notes || '').slice(0, 100)}${(r.notes || '').length > 100 ? '...' : ''}</div>
                                    </div>
                                    <button class="btn-secondary text-xs !py-1.5 !px-3" onclick="viewAnamneseDetail('${r.id}'); openModal('modal-anamnese-history');">
                                        <i class="fa-solid fa-eye mr-1"></i>Ver
                                    </button>
                                </div>
                            `).join('');
                        }
                    }
                } catch(err) { 
                    console.error('preview render error', err); 
                }

                updateListsAndTotals();
            }
        }
    } else {
        document.getElementById('area-clinica-empty').classList.remove('hidden');
        document.getElementById('area-clinica-active').classList.add('hidden');
    }
}

function startConsultation(id) {
    if(currentConsultationId && currentConsultationId !== id) {
        if(!confirm("Já existe um atendimento em andamento. Deseja trocar de paciente?")) return;
    }
    
    const appt = DB.agendamentos.find(a => a.id === id);
    if (appt) {
        appt.status = 'Em Atendimento';
        currentConsultationId = id; 
        tempPrescription = []; 
        tempExams = []; 
        tempAnamnese = null;
        saveDB(); 
        renderAtendimentoScreen();
        showToast(`Atendimento iniciado: ${appt.pacienteNome}`);
    }
}

function updateListsAndTotals() {
    document.getElementById('prescription-list').innerHTML = tempPrescription.length > 0
        ? tempPrescription.map((i,x) => `
            <div class="flex justify-between items-center py-2 border-b border-[#CBE5F7] border-opacity-30">
                <div>
                    <span class="font-medium text-gray-800">${i.nome}</span>
                    <span class="text-sm text-gray-500 ml-2">${i.qtd}x ${formatCurrency(i.total)}</span>
                </div>
                <button onclick="removeTempItem('med',${x})" class="text-red-500 hover:text-red-700 transition-colors">
                    <i class="fa-solid fa-trash-can"></i>
                </button>
            </div>
        `).join('')
        : '<div class="text-gray-400 text-center py-4">Nenhum medicamento prescrito</div>';
    
    document.getElementById('exams-list').innerHTML = tempExams.length > 0
        ? tempExams.map((i,x) => `
            <div class="flex justify-between items-center py-2 border-b border-[#CBE5F7] border-opacity-30">
                <div>
                    <span class="font-medium text-gray-800">${i.nome}</span>
                    <span class="text-sm text-gray-500 ml-2">${formatCurrency(i.preco)}</span>
                </div>
                <button onclick="removeTempItem('exam',${x})" class="text-red-500 hover:text-red-700 transition-colors">
                    <i class="fa-solid fa-trash-can"></i>
                </button>
            </div>
        `).join('')
        : '<div class="text-gray-400 text-center py-4">Nenhum exame solicitado</div>';
    
    const totMeds = tempPrescription.reduce((s,i) => s + i.total, 0);
    const totExams = tempExams.reduce((s,i) => s + i.preco, 0);
    const appt = DB.agendamentos.find(a => a.id === currentConsultationId);
    
    document.getElementById('total-meds').innerText = formatCurrency(totMeds);
    document.getElementById('total-exams').innerText = formatCurrency(totExams);
    document.getElementById('total-final').innerText = formatCurrency((appt?.valor || 0) + totMeds + totExams);
}

window.removeTempItem = (t, i) => { 
    if(t === 'med') tempPrescription.splice(i,1); 
    else tempExams.splice(i,1); 
    updateListsAndTotals(); 
};

function addMedicationToPrescription() {
    const id = document.getElementById('consult-medication').value; 
    const qty = parseInt(document.getElementById('consult-qty').value);
    const item = DB.estoque.find(e => e.id === id);
    
    if(item) { 
        tempPrescription.push({
            id: item.id, 
            nome: item.nome, 
            qtd: qty, 
            total: item.preco * qty
        }); 
        updateListsAndTotals(); 
        showToast(`${item.nome} adicionado à prescrição`);
    } else {
        showToast('Selecione um medicamento', 'error');
    }
}

function addExamToConsultation() {
    const id = document.getElementById('consult-exam').value;
    const item = DB.catalogoExames.find(e => e.id === id);
    
    if(item) { 
        tempExams.push({
            id: item.id, 
            nome: item.nome, 
            preco: item.preco
        }); 
        updateListsAndTotals(); 
        showToast(`${item.nome} adicionado à solicitação`);
    } else {
        showToast('Selecione um exame', 'error');
    }
}

function proceedToPayment() { 
    document.getElementById('pay-total-val').innerText = document.getElementById('total-final').innerText; 
    openModal('modal-pagamento'); 
}

function confirmPayment() {
    const appt = DB.agendamentos.find(a => a.id === currentConsultationId);
    if (appt) {
        appt.status = 'Finalizado';
        
        DB.financeiro.push({ 
            id: generateId(), 
            data: new Date().toISOString(), 
            pacienteId: appt.pacienteId, 
            pacienteNome: appt.pacienteNome, 
            tipo: appt.tipo, 
            valor: parseFloat(document.getElementById('total-final').innerText.replace('R$', '').replace('.', '').replace(',', '.')), 
            metodo: document.getElementById('pay-method').value,
            parcelas: parseInt(document.getElementById('pay-installments').value) || 1
        });
        
        DB.atendimentos.push({ 
            id: generateId(), 
            agendamentoId: appt.id, 
            pacienteId: appt.pacienteId, 
            data: appt.data, 
            prescricao: tempPrescription, 
            exames: tempExams,
            anamnese: tempAnamnese || {} 
        });
        
        saveDB(); 
        closeModal('modal-pagamento'); 
        showToast(`Atendimento finalizado com sucesso!`);
        currentConsultationId = null; 
        renderAtendimentoScreen();
    }
}

// ============================================
// FORMS
// ============================================

document.addEventListener('submit', (e) => {
    e.preventDefault();
    
    if(e.target.id === 'form-paciente') {
        const editingId = document.getElementById('pac-id').value;
        const existing = DB.pacientes.find(p => p.id === editingId);
        const p = { 
            id: editingId || generateId(), 
            nome: document.getElementById('pac-nome').value, 
            cpf: document.getElementById('pac-cpf').value, 
            dataNascimento: document.getElementById('pac-nasc').value, 
            endereco: document.getElementById('pac-endereco').value, 
            tipoAtendimento: document.getElementById('pac-tipo').value, 
            tel: document.getElementById('pac-tel').value, 
            lgpdConsent: document.getElementById('pac-lgpd')?.checked || false,
            dataCadastro: existing?.dataCadastro || new Date().toISOString() 
        };
        
        if (existing) {
            Object.assign(existing, p);
            DB.agendamentos.forEach(a => {
                if (a.pacienteId === existing.id) a.pacienteNome = existing.nome;
            });
            DB.financeiro.forEach(f => {
                if (f.pacienteId === existing.id) f.pacienteNome = existing.nome;
            });
            saveDB(); 
            renderPacientes(); 
            updateDashboard();
            closeModal('modal-paciente');
            showToast(`Paciente ${p.nome} atualizado com sucesso!`);
        } else {
            DB.pacientes.push(p); 
            saveDB(); 
            renderPacientes(); 
            updateDashboard();
            closeModal('modal-paciente');
            showToast(`Paciente ${p.nome} cadastrado com sucesso!`);
        }
    }
    
    if(e.target.id === 'form-agendamento') {
        const pacienteId = document.getElementById('ag-paciente').value;
        const paciente = DB.pacientes.find(p => p.id === pacienteId);
        
        if (!paciente) {
            showToast('Selecione um paciente', 'error');
            return;
        }
        
        const ag = {
            id: generateId(), 
            pacienteId: pacienteId, 
            pacienteNome: paciente.nome,
            data: document.getElementById('ag-data').value, 
            hora: document.getElementById('ag-hora').value,
            motivo: document.getElementById('ag-motivo').value, 
            tipo: document.getElementById('ag-tipo').value,
            valor: parseFloat(document.getElementById('ag-valor').value), 
            prioridade: document.getElementById('ag-prioridade').value,
            status: 'Agendado',
            sessoes: parseInt(document.getElementById('ag-qtd-sessoes').value) || 1
        };
        
        DB.agendamentos.push(ag); 
        saveDB(); 
        renderCalendar(); 
        updateDashboard(); 
        closeModal('modal-agendamento');
        showToast(`Agendamento criado para ${paciente.nome}`);
    }
    
    if(e.target.id === 'form-novo-protocolo') {
        const servicos = {
            'Consulta': parseInt(document.getElementById('prot-cred-consulta').value) || 0,
            'Nutricionista': parseInt(document.getElementById('prot-cred-nutri').value) || 0,
            'Exame': parseInt(document.getElementById('prot-cred-exame').value) || 0,
            'Procedimento': parseInt(document.getElementById('prot-cred-proced').value) || 0
        };
        
        const np = { 
            id: generateId(), 
            nome: document.getElementById('prot-nome').value, 
            valor: parseFloat(document.getElementById('prot-valor').value), 
            duracao: parseInt(document.getElementById('prot-dias').value) || 30, 
            servicos: Object.fromEntries(Object.entries(servicos).filter(([_,v]) => v > 0))
        };
        
        DB.protocolos.push(np); 
        saveDB(); 
        renderProtocolos(); 
        closeModal('modal-novo-protocolo');
        showToast(`Protocolo ${np.nome} criado com sucesso!`);
    }
    
    if(e.target.id === 'form-estoque') {
        const item = {
            id: generateId(),
            nome: document.getElementById('est-nome').value,
            lote: document.getElementById('est-lote').value || 'N/A',
            validade: document.getElementById('est-validade').value,
            qtd: parseInt(document.getElementById('est-qtd').value),
            min: parseInt(document.getElementById('est-min').value) || 10,
            custo: parseFloat(document.getElementById('est-custo').value),
            preco: parseFloat(document.getElementById('est-preco').value),
            dataEntrada: getTodayISO()
        };
        
        DB.estoque.push(item);
        DB.financeiro.push({
            id: generateId(),
            data: item.dataEntrada,
            pacienteId: null,
            pacienteNome: 'Estoque',
            tipo: 'Compra de estoque',
            valor: -Math.abs((Number(item.qtd) || 0) * (Number(item.custo) || 0)),
            metodo: 'Custo interno',
            parcelas: 1,
            origem: 'Estoque',
            categoria: 'despesa_estoque',
            estoqueItemId: item.id,
            detalhes: { item: item.nome, lote: item.lote }
        });
        saveDB();
        renderEstoque();
        if (document.getElementById('table-financial-body')) renderFinancialReport();
        updateDashboard();
        closeModal('modal-estoque');
        showToast(`${item.nome} adicionado ao estoque`);
    }
});

// ============================================
// HELPERS
// ============================================

function populatePatientSelect() { 
    const select = document.getElementById('ag-paciente');
    if (select) {
        select.innerHTML = '<option value="">Selecione um paciente...</option>' + 
            DB.pacientes.sort((a,b) => a.nome.localeCompare(b.nome))
                .map(p => `<option value="${p.id}">${p.nome} • ${p.cpf || ''}</option>`).join(''); 
    }
}

function editPatient(id) { 
    const paciente = DB.pacientes.find(p => p.id === id);
    if (!paciente) return;

    openModal('modal-paciente');
    document.getElementById('pac-id').value = paciente.id;
    document.getElementById('pac-nome').value = paciente.nome || '';
    document.getElementById('pac-cpf').value = paciente.cpf || '';
    document.getElementById('pac-nasc').value = paciente.dataNascimento || '';
    document.getElementById('pac-endereco').value = paciente.endereco || '';
    document.getElementById('pac-tipo').value = paciente.tipoAtendimento || '';
    document.getElementById('pac-tel').value = paciente.tel || '';
    document.getElementById('pac-lgpd').checked = !!paciente.lgpdConsent;

    const title = document.getElementById('modal-paciente-title');
    const submitBtn = document.querySelector('#form-paciente button[type="submit"]');
    if (title) title.innerText = `Editar Paciente`;
    if (submitBtn) submitBtn.innerText = 'Salvar Alterações';
}

function editProtocol(id) {
    const protocolo = DB.protocolos.find(p => p.id === id);
    if (!protocolo) return;

    openModal('modal-novo-protocolo');
    document.getElementById('form-novo-protocolo').dataset.editingId = protocolo.id;
    document.getElementById('prot-nome').value = protocolo.nome || '';
    document.getElementById('prot-valor').value = Number(protocolo.valor || 0);
    document.getElementById('prot-dias').value = Number(protocolo.duracao || 30);
    document.getElementById('prot-cred-consulta').value = Number(protocolo.servicos?.Consulta || 0);
    document.getElementById('prot-cred-nutri').value = Number(protocolo.servicos?.Nutricionista || 0);
    document.getElementById('prot-cred-exame').value = Number(protocolo.servicos?.Exame || 0);
    document.getElementById('prot-cred-proced').value = Number(protocolo.servicos?.Procedimento || 0);

    const title = document.querySelector('#modal-novo-protocolo h3');
    const submitBtn = document.querySelector('#form-novo-protocolo button[type="submit"]');
    if (title) title.innerText = 'Editar Protocolo';
    if (submitBtn) submitBtn.innerText = 'Salvar Alterações';
}

// ============================================
// ANAMNESE
// ============================================

function renderQuestionnaire() {
    const container = document.getElementById('questions-container'); 
    if(!container) return;
    container.innerHTML = '';
    
    let pacienteId = null;
    if (currentConsultationId) { 
        const ap = DB.agendamentos.find(a => a.id === currentConsultationId); 
        pacienteId = ap?.pacienteId; 
    }
    if (!pacienteId && currentQuickPatientId) pacienteId = currentQuickPatientId;

    const last = (DB.avaliacoes||[])
        .filter(a => a.pacienteId === pacienteId)
        .sort((a,b) => new Date(b.timestamp) - new Date(a.timestamp))[0];

    STANDARD_QUESTIONS.forEach((q, idx) => {
        const id = 'q_' + idx;
        const prev = last && last.perguntas && last.perguntas[id] ? last.perguntas[id] : {};
        
        const block = document.createElement('div'); 
        block.className = 'p-5 bg-[#FCF7F9] rounded-2xl border border-[#CBE5F7] border-opacity-30';
        block.innerHTML = `
            <div class="font-heading font-bold text-[#6F4B36] mb-3">${idx + 1}. ${q}</div>
            <div class="grid grid-cols-2 gap-4 mb-3">
                <div>
                    <label class="text-xs text-gray-500 block mb-1">Antes (0-10)</label>
                    <input type="number" min="0" max="10" id="${id}_antes" 
                           value="${prev.antes || ''}" 
                           class="w-full text-center bg-white rounded-xl border-[#CBE5F7]">
                </div>
                <div>
                    <label class="text-xs text-gray-500 block mb-1">Depois (0-10)</label>
                    <input type="number" min="0" max="10" id="${id}_depois" 
                           value="${prev.depois || ''}" 
                           class="w-full text-center bg-white rounded-xl border-[#CBE5F7]">
                </div>
            </div>
            <textarea id="${id}_resp" rows="2" 
                      class="w-full bg-white rounded-xl border-[#CBE5F7]" 
                      placeholder="Observações...">${prev.resposta || ''}</textarea>
        `;
        container.appendChild(block);
    });
    
    const notes = document.createElement('div'); 
    notes.className = 'mt-6 p-5 bg-[#FCF7F9] rounded-2xl border border-[#CBE5F7] border-opacity-30';
    notes.innerHTML = `
        <label class="font-heading font-bold text-[#6F4B36] block mb-2">Observações Gerais</label>
        <textarea id="anamnese-notes" class="w-full bg-white rounded-xl border-[#CBE5F7]" rows="3">${last && last.notes ? last.notes : ''}</textarea>
    `;
    container.appendChild(notes);
}

function saveAnamnese() {
    try {
        let pacienteId = null;
        if (currentConsultationId) { 
            const ap = DB.agendamentos.find(a => a.id === currentConsultationId); 
            pacienteId = ap?.pacienteId; 
        }
        if (!pacienteId && currentQuickPatientId) pacienteId = currentQuickPatientId;
        
        if(!pacienteId) { 
            showToast('Nenhum paciente selecionado', 'error'); 
            return; 
        }
        
        const perguntas = {};
        STANDARD_QUESTIONS.forEach((q, idx) => {
            const id = 'q_' + idx;
            const antes = document.getElementById(id + '_antes')?.value || '';
            const depois = document.getElementById(id + '_depois')?.value || '';
            const resposta = document.getElementById(id + '_resp')?.value || '';
            perguntas[id] = { 
                pergunta: q, 
                antes: antes, 
                depois: depois, 
                resposta 
            };
        });
        
        const rec = { 
            id: generateId(), 
            pacienteId, 
            timestamp: new Date().toISOString(), 
            perguntas, 
            notes: document.getElementById('anamnese-notes')?.value || '' 
        };
        
        DB.avaliacoes = DB.avaliacoes || [];
        DB.avaliacoes.unshift(rec);
        tempAnamnese = rec;
        saveDB(); 
        closeModal('modal-questionnaire'); 
        showToast('Anamnese salva com sucesso');
        renderAtendimentoScreen();
    } catch (err) { 
        console.error('saveAnamnese', err); 
        showToast('Erro ao salvar anamnese', 'error'); 
    }
}

window.openQuestionnaire = () => { 
    renderQuestionnaire(); 
    openModal('modal-questionnaire'); 
};

window.saveAnamnese = saveAnamnese;

function openAnamneseHistory(pacienteId) {
    const list = document.getElementById('anamnese-history-list'); 
    const detail = document.getElementById('anamnese-detail');
    if(!list) return; 
    
    list.innerHTML = ''; 
    detail.innerHTML = '';
    
    const items = (DB.avaliacoes||[])
        .filter(a => a.pacienteId === pacienteId)
        .sort((a,b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    if(items.length === 0) { 
        list.innerHTML = '<div class="text-center py-8 text-gray-400 bg-[#FCF7F9] rounded-2xl">Nenhum registro de anamnese encontrado.</div>'; 
    } else {
        items.forEach(it => {
            const d = new Date(it.timestamp).toLocaleString();
            const el = document.createElement('div'); 
            el.className = 'p-4 bg-[#FCF7F9] rounded-2xl border border-[#CBE5F7] flex justify-between items-center';
            el.innerHTML = `
                <div>
                    <div class="font-medium text-gray-800">${d}</div>
                    <div class="text-xs text-gray-500 mt-1">${(it.notes || '').slice(0, 120)}${(it.notes || '').length > 120 ? '...' : ''}</div>
                </div>
                <div>
                    <button class="btn-secondary text-xs !py-2 !px-4" onclick="viewAnamneseDetail('${it.id}')">
                        <i class="fa-solid fa-eye mr-1"></i>Ver
                    </button>
                </div>
            `;
            list.appendChild(el);
        });
    }
    
    const atendList = DB.atendimentos
        .filter(a => a.pacienteId === pacienteId)
        .sort((a,b) => new Date(b.data) - new Date(a.data))
        .slice(0, 5);
    
    if(atendList.length > 0) {
        const h = document.createElement('div'); 
        h.className = 'mt-6';
        h.innerHTML = `
            <div class="font-heading font-bold text-[#6F4B36] mb-3">Atendimentos Recentes</div>
            <div class="space-y-2">
                ${atendList.map(at => `
                    <div class="bg-white p-3 rounded-xl border border-[#CBE5F7] text-sm">
                        <span class="font-medium text-gray-800">${formatDate(at.data)}</span>
                        <span class="text-gray-500 ml-2">• ${at.id.slice(0,8)}</span>
                    </div>
                `).join('')}
            </div>
        `;
        list.appendChild(h);
    }
    
    openModal('modal-anamnese-history');
}

function viewAnamneseDetail(id) {
    const rec = (DB.avaliacoes||[]).find(a => a.id === id); 
    const detail = document.getElementById('anamnese-detail'); 
    if(!rec || !detail) return;
    
    let html = `
        <div class="bg-white p-4 rounded-xl border border-[#CBE5F7] mb-4">
            <div class="font-bold text-[#6F4B36] mb-1">Data do Registro</div>
            <div class="text-gray-800">${new Date(rec.timestamp).toLocaleString()}</div>
        </div>
    `;
    
    if (rec.notes) {
        html += `
            <div class="bg-white p-4 rounded-xl border border-[#CBE5F7] mb-4">
                <div class="font-bold text-[#6F4B36] mb-1">Observações Gerais</div>
                <div class="text-gray-700">${rec.notes}</div>
            </div>
        `;
    }
    
    html += '<div class="space-y-3">';
    
    if (rec.perguntas) {
        Object.keys(rec.perguntas).forEach(k => {
            const q = rec.perguntas[k]; 
            html += `
                <div class="bg-white p-4 rounded-xl border border-[#CBE5F7]">
                    <div class="font-medium text-[#6F4B36] text-sm mb-2">${q.pergunta || 'Pergunta'}</div>
                    <div class="grid grid-cols-2 gap-4 mb-2 text-xs">
                        <div class="bg-[#FCF7F9] p-2 rounded-lg">
                            <span class="text-gray-500">Antes:</span> 
                            <span class="font-bold text-[#6F4B36]">${q.antes || '—'}</span>
                        </div>
                        <div class="bg-[#FCF7F9] p-2 rounded-lg">
                            <span class="text-gray-500">Depois:</span> 
                            <span class="font-bold text-[#6F4B36]">${q.depois || '—'}</span>
                        </div>
                    </div>
                    <div class="text-sm text-gray-700 bg-[#FCF7F9] p-3 rounded-lg">
                        ${q.resposta || 'Sem observações'}
                    </div>
                </div>
            `;
        });
    }
    
    html += '</div>';
    detail.innerHTML = html;
}

window.openPatientReport = (id) => { 
    const p = DB.pacientes.find(x => x.id === id); 
    if (p) {
        document.getElementById('rep-nome').innerText = p.nome; 
        document.getElementById('rep-cpf').innerText = p.cpf || '';
        document.getElementById('rep-tel').innerText = p.tel || '';
        document.getElementById('rep-generated-date').innerText = new Date().toLocaleString();
        
        // Calcular total investido
        const financeiroPaciente = DB.financeiro.filter(f => f.pacienteId === id);
        const totalInvestido = financeiroPaciente.reduce((sum, f) => sum + f.valor, 0);
        document.getElementById('rep-total-invested').innerHTML = formatCurrency(totalInvestido);
        
        // Timeline de atendimentos
        const atendimentos = DB.atendimentos
            .filter(a => a.pacienteId === id)
            .sort((a,b) => new Date(b.data) - new Date(a.data));
        
        const timeline = document.getElementById('timeline-container');
        if (timeline) {
            timeline.innerHTML = '<div class="timeline-line"></div>';
            
            if (atendimentos.length > 0) {
                atendimentos.slice(0, 10).forEach((at, idx) => {
                    const isFirst = idx === 0;
                    const isLast = idx === atendimentos.length - 1;
                    
                    const eventDiv = document.createElement('div');
                    eventDiv.className = `relative pl-6 ${isLast ? '' : 'pb-6'}`;
                    eventDiv.innerHTML = `
                        <div class="absolute left-0 top-1 w-4 h-4 bg-white border-3 border-[#6F4B36] rounded-full z-10"></div>
                        <div class="bg-[#FCF7F9] p-4 rounded-xl border border-[#CBE5F7]">
                            <div class="flex justify-between items-start">
                                <div>
                                    <span class="font-bold text-[#6F4B36]">${formatDate(at.data)}</span>
                                    <span class="text-xs text-gray-500 ml-2">${at.id.slice(0,8)}</span>
                                </div>
                                <span class="badge badge-secondary">Atendimento</span>
                            </div>
                            <div class="mt-2 text-sm text-gray-700">
                                ${at.anamnese ? '<span class="font-medium">Queixa:</span> ' + (at.anamnese.note || at.anamnese['5'] || 'Não registrada') : 'Sem dados'}
                            </div>
                        </div>
                    `;
                    timeline.appendChild(eventDiv);
                });
            } else {
                timeline.innerHTML = '<div class="text-center py-8 text-gray-400">Nenhum atendimento registrado</div>';
            }
        }
        
        // Financeiro
        const repFinanceiro = document.getElementById('rep-financeiro-body');
        if (repFinanceiro) {
            repFinanceiro.innerHTML = financeiroPaciente
                .sort((a,b) => new Date(b.data) - new Date(a.data))
                .map(f => `
                    <tr>
                        <td class="p-2 border border-[#CBE5F7]">${formatDate(f.data.split('T')[0])}</td>
                        <td class="p-2 border border-[#CBE5F7]">${f.tipo}</td>
                        <td class="p-2 border border-[#CBE5F7] text-right font-mono">${formatCurrency(f.valor)}</td>
                        <td class="p-2 border border-[#CBE5F7]">${f.metodo || '—'}</td>
                    </tr>
                `).join('');
        }
        
        openModal('modal-relatorio-geral'); 
    }
};

window.renderPatientQuickReport = (id) => { 
    const p = DB.pacientes.find(x => x.id === id); 
    if (p) {
        document.getElementById('quick-name').innerText = p.nome; 
        document.getElementById('quick-cpf').innerText = p.cpf || '';
        document.getElementById('quick-tel').innerText = p.tel || '—';
        document.getElementById('quick-type-badge').innerHTML = `<span class="badge ${p.tipoAtendimento === 'Particular' ? 'badge-primary' : 'badge-secondary'}">${p.tipoAtendimento}</span>`;
        
        // Última visita
        const lastAtendimento = DB.atendimentos
            .filter(a => a.pacienteId === id)
            .sort((a,b) => new Date(b.data) - new Date(a.data))[0];
        
        document.getElementById('quick-last-visit').innerText = lastAtendimento ? formatDate(lastAtendimento.data) : 'Nunca';
        
        // Última anamnese
        const lastAnamnese = (DB.avaliacoes||[])
            .filter(a => a.pacienteId === id)
            .sort((a,b) => new Date(b.timestamp) - new Date(a.timestamp))[0];
        
        document.getElementById('quick-last-anamnese').innerText = lastAnamnese?.notes?.slice(0, 80) + '...' || 'Nenhum registro';
        
        // Total investido
        const totalSpent = DB.financeiro
            .filter(f => f.pacienteId === id)
            .reduce((sum, f) => sum + f.valor, 0);
        
        document.getElementById('quick-total-spent').innerText = formatCurrency(totalSpent);
        
        // Alertas
        const alertsDiv = document.getElementById('quick-alerts');
        const hasPending = DB.agendamentos.some(a => a.pacienteId === id && a.status !== 'Finalizado');
        alertsDiv.innerHTML = hasPending ? '<span class="badge badge-primary"><i class="fa-regular fa-clock mr-1"></i>Agendamento pendente</span>' : '';
        
        currentQuickPatientId = id;
        document.getElementById('patient-quick-panel').classList.remove('hidden');
    }
};

window.openFullReportFromQuick = () => {
    if (currentQuickPatientId) {
        openPatientReport(currentQuickPatientId);
    }
};

window.openSellProtocolModal = () => {
    if (currentQuickPatientId) {
        const paciente = DB.pacientes.find(p => p.id === currentQuickPatientId);
        showToast(`Funcionalidade de venda de protocolos em desenvolvimento para ${paciente?.nome}`, 'error');
    }
};

function renderEstoque() { 
    document.getElementById('table-estoque-body').innerHTML = DB.estoque.map(e => {
        const hoje = new Date();
        const validade = new Date(e.validade);
        const diasValidade = Math.floor((validade - hoje) / (1000*60*60*24));
        const statusClass = validade < hoje ? 'badge-primary' : 
                           (diasValidade < 30 ? 'badge-primary' : 
                           (e.qtd <= e.min ? 'badge-primary' : 'badge-secondary'));
        const statusText = validade < hoje ? 'Vencido' : 
                          (diasValidade < 30 ? 'Vence em breve' : 
                          (e.qtd <= e.min ? 'Estoque baixo' : 'OK'));
        
        return `<tr class="hover:bg-[#FCF7F9]">
            <td class="p-3 font-medium text-gray-800">${e.nome}</td>
            <td class="p-3 text-gray-600">${e.lote}</td>
            <td class="p-3 text-gray-600">${formatDate(e.validade)}</td>
            <td class="p-3 text-center font-mono">${e.qtd} un</td>
            <td class="p-3 text-right font-mono text-gray-600">${formatCurrency(e.custo)}</td>
            <td class="p-3 text-right font-mono text-[#6F4B36] font-bold">${formatCurrency(e.preco)}</td>
            <td class="p-3 text-center"><span class="badge ${statusClass}">${statusText}</span></td>
        </tr>`;
    }).join(''); 
}


function ensureFinancialFilters() {
    const section = document.getElementById('financeiro');
    if (!section || document.getElementById('financial-filters-bar')) return;

    const titleRow = section.querySelector('.flex.justify-between.items-center.mb-6.no-print');
    if (!titleRow) return;

    const filters = document.createElement('div');
    filters.id = 'financial-filters-bar';
    filters.className = 'flex flex-wrap items-end gap-3 mb-6 no-print';
    filters.innerHTML = `
        <div>
            <label class="font-heading text-xs font-bold text-gray-600 block mb-2">Agrupar por</label>
            <select id="financial-filter-mode" class="px-4 py-3 rounded-2xl border border-[#CBE5F7] bg-white">
                <option value="month">Mês</option>
                <option value="year">Ano</option>
            </select>
        </div>
        <div id="financial-filter-month-wrap">
            <label class="font-heading text-xs font-bold text-gray-600 block mb-2">Mês</label>
            <select id="financial-filter-month" class="px-4 py-3 rounded-2xl border border-[#CBE5F7] bg-white">
                <option value="0">Janeiro</option>
                <option value="1">Fevereiro</option>
                <option value="2">Março</option>
                <option value="3">Abril</option>
                <option value="4">Maio</option>
                <option value="5">Junho</option>
                <option value="6">Julho</option>
                <option value="7">Agosto</option>
                <option value="8">Setembro</option>
                <option value="9">Outubro</option>
                <option value="10">Novembro</option>
                <option value="11">Dezembro</option>
            </select>
        </div>
        <div>
            <label class="font-heading text-xs font-bold text-gray-600 block mb-2">Ano</label>
            <select id="financial-filter-year" class="px-4 py-3 rounded-2xl border border-[#CBE5F7] bg-white"></select>
        </div>
        <div class="ml-auto flex gap-3">
            <div class="card px-4 py-3 min-w-[150px]">
                <div class="text-xs uppercase tracking-wide text-gray-500">Receitas</div>
                <div id="financial-total-receitas" class="font-heading text-lg font-bold text-[#6F4B36]">R$ 0,00</div>
            </div>
            <div class="card px-4 py-3 min-w-[150px]">
                <div class="text-xs uppercase tracking-wide text-gray-500">Despesas</div>
                <div id="financial-total-despesas" class="font-heading text-lg font-bold text-red-600">R$ 0,00</div>
            </div>
        </div>
    `;
    titleRow.insertAdjacentElement('afterend', filters);

    document.getElementById('financial-filter-mode').addEventListener('change', (e) => {
        financialFilterMode = e.target.value;
        toggleFinancialMonthFilter();
        renderFinancialReport();
    });
    document.getElementById('financial-filter-month').addEventListener('change', (e) => {
        financialFilterMonth = Number(e.target.value);
        renderFinancialReport();
    });
    document.getElementById('financial-filter-year').addEventListener('change', (e) => {
        financialFilterYear = Number(e.target.value);
        renderFinancialReport();
    });
}

function populateFinancialYearOptions(entries) {
    const yearSelect = document.getElementById('financial-filter-year');
    if (!yearSelect) return;
    const years = [...new Set(entries.map(entry => getYearFromDate(entry.data)).filter(Boolean))].sort((a, b) => b - a);
    const currentYear = new Date().getFullYear();
    if (!years.includes(currentYear)) years.unshift(currentYear);
    yearSelect.innerHTML = years.map(year => `<option value="${year}">${year}</option>`).join('');
    if (!years.includes(financialFilterYear)) financialFilterYear = years[0] || currentYear;
    yearSelect.value = String(financialFilterYear);
}

function toggleFinancialMonthFilter() {
    const wrap = document.getElementById('financial-filter-month-wrap');
    const modeSelect = document.getElementById('financial-filter-mode');
    const monthSelect = document.getElementById('financial-filter-month');
    if (modeSelect) modeSelect.value = financialFilterMode;
    if (monthSelect) monthSelect.value = String(financialFilterMonth);
    if (wrap) wrap.style.display = financialFilterMode === 'month' ? 'block' : 'none';
}

function getFilteredFinancialEntries(entries = buildFinancialEntries()) {
    return entries.filter(entry => {
        const year = getYearFromDate(entry.data);
        if (year !== financialFilterYear) return false;
        if (financialFilterMode === 'month') {
            return getMonthFromDate(entry.data) === financialFilterMonth;
        }
        return true;
    });
}

function renderFinancialReport() { 
    ensureFinancialFilters();
    const entries = buildFinancialEntries();
    populateFinancialYearOptions(entries);
    toggleFinancialMonthFilter();

    const filteredEntries = getFilteredFinancialEntries(entries);
    document.getElementById('table-financial-body').innerHTML = filteredEntries.length
        ? filteredEntries.map(f => {
            const isExpense = Number(f.valor) < 0;
            const badgeClass = isExpense ? 'badge-primary' : 'badge-secondary';
            const personLabel = f.pacienteNome || f.origem || '—';
            const valueClass = isExpense ? 'text-red-600' : 'text-[#6F4B36]';
            return `
        <tr class="hover:bg-[#FCF7F9]">
            <td class="p-3 text-gray-600">${formatDate((f.data || '').split('T')[0])}</td>
            <td class="p-3 font-medium text-gray-800">${personLabel}</td>
            <td class="p-3 text-gray-600">${f.tipo}</td>
            <td class="p-3 text-right font-mono font-bold ${valueClass}">${formatCurrency(f.valor)}</td>
            <td class="p-3 text-center"><span class="badge ${badgeClass}">${f.metodo || f.origem || '—'}</span></td>
        </tr>`;
        }).join('')
        : `<tr><td colspan="5" class="p-4 text-center text-gray-500">Nenhum lançamento encontrado para o período selecionado.</td></tr>`;

    const receitas = filteredEntries.filter(f => Number(f.valor || 0) > 0).reduce((s,f) => s + Number(f.valor || 0), 0);
    const despesas = filteredEntries.filter(f => Number(f.valor || 0) < 0).reduce((s,f) => s + Math.abs(Number(f.valor || 0)), 0);
    const saldo = receitas - despesas;
    document.getElementById('financial-total-sum').innerText = formatCurrency(saldo);

    const receitasEl = document.getElementById('financial-total-receitas');
    const despesasEl = document.getElementById('financial-total-despesas');
    if (receitasEl) receitasEl.innerText = formatCurrency(receitas);
    if (despesasEl) despesasEl.innerText = formatCurrency(despesas);
}

function renderRelatorios() { 
    document.getElementById('table-relatorios-body').innerHTML = DB.pacientes.map(p => {
        const atendimentos = DB.atendimentos.filter(a => a.pacienteId === p.id).length;
        const totalInvestido = DB.financeiro.filter(f => f.pacienteId === p.id).reduce((s,f) => s + f.valor, 0);
        const ultimaVisita = DB.atendimentos
            .filter(a => a.pacienteId === p.id)
            .sort((a,b) => new Date(b.data) - new Date(a.data))[0];
        
        return `<tr class="hover:bg-[#FCF7F9]">
            <td class="p-3 font-medium text-gray-800">${p.nome}</td>
            <td class="p-3 text-gray-600">${p.cpf || '—'}</td>
            <td class="p-3 text-center"><span class="badge badge-secondary">${atendimentos}</span></td>
            <td class="p-3 text-right font-mono text-[#6F4B36] font-bold">${formatCurrency(totalInvestido)}</td>
            <td class="p-3 text-center text-gray-600">${ultimaVisita ? formatDate(ultimaVisita.data) : '—'}</td>
            <td class="p-3 text-center">
                <button onclick="openPatientReport('${p.id}')" class="text-[#6F4B36] hover:text-[#5A3C2B] transition-colors mx-1" title="Prontuário">
                    <i class="fa-solid fa-file-medical"></i>
                </button>
            </td>
        </tr>`;
    }).join(''); 
}

function renderAuditoria() { 
    document.getElementById('table-auditoria-body').innerHTML = DB.auditoria
        .slice(0, 50)
        .map(a => `
        <tr class="hover:bg-[#FCF7F9]">
            <td class="p-3 text-gray-600">${new Date(a.timestamp).toLocaleString()}</td>
            <td class="p-3 font-medium text-gray-800">${a.usuario}</td>
            <td class="p-3 text-gray-600">${a.acao}</td>
            <td class="p-3 text-xs text-gray-500 font-mono truncate max-w-xs">${a.detalhes?.slice(0, 50) || '—'}</td>
        </tr>
    `).join(''); 
}


function renderStrategyTable() {
    const tbody = document.getElementById('table-estrategia-body');
    if (!tbody) return;

    const entryYears = buildFinancialEntries().map(entry => getYearFromDate(entry.data));
    const patientYears = (DB.pacientes || []).map(p => getYearFromDate(p.dataCadastro || p.createdAt || getTodayISO()));
    const years = [...new Set([...entryYears, ...patientYears])].filter(Boolean).sort((a, b) => b - a);

    tbody.innerHTML = years.map(year => {
        const yearEntries = buildFinancialEntries().filter(entry => getYearFromDate(entry.data) === year);
        const receitas = yearEntries.filter(entry => Number(entry.valor || 0) > 0).reduce((sum, entry) => sum + Number(entry.valor || 0), 0);
        const custos = yearEntries.filter(entry => Number(entry.valor || 0) < 0).reduce((sum, entry) => sum + Math.abs(Number(entry.valor || 0)), 0);
        const margem = receitas - custos;
        const novosPacientes = (DB.pacientes || []).filter(patient => getYearFromDate(patient.dataCadastro || patient.createdAt || getTodayISO()) === year).length;
        const ticketMedio = novosPacientes > 0 ? receitas / novosPacientes : 0;

        return `
            <tr class="hover:bg-[#FCF7F9]">
                <td class="p-3 font-bold text-gray-800">${year}</td>
                <td class="p-3 text-right font-mono text-[#6F4B36]">${formatCurrency(receitas)}</td>
                <td class="p-3 text-right font-mono text-red-600">${formatCurrency(custos)}</td>
                <td class="p-3 text-right font-mono font-bold ${margem >= 0 ? 'text-green-600' : 'text-red-600'}">${formatCurrency(margem)}</td>
                <td class="p-3 text-center">${novosPacientes}</td>
                <td class="p-3 text-center">${formatCurrency(ticketMedio)}</td>
            </tr>
        `;
    }).join('');

    if (!tbody.innerHTML.trim()) {
        tbody.innerHTML = `<tr><td colspan="6" class="p-4 text-center text-gray-500">Nenhum dado disponível para o DRE simplificado.</td></tr>`;
    }
}

function renderAnalytics() { 
    const financeCanvas = document.getElementById('chart-financeiro-anual');
    const patientsCanvas = document.getElementById('chart-pacientes-anual');
    if (!financeCanvas || !patientsCanvas || typeof Chart === 'undefined') return;

    const currentYear = new Date().getFullYear();
    const labels = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    const receitas = new Array(12).fill(0);
    const despesas = new Array(12).fill(0);
    const novosPacientes = new Array(12).fill(0);

    buildFinancialEntries().forEach(entry => {
        const year = getYearFromDate(entry.data);
        if (year !== currentYear) return;
        const month = getMonthFromDate(entry.data);
        const value = Number(entry.valor || 0);
        if (value >= 0) receitas[month] += value;
        else despesas[month] += Math.abs(value);
    });

    (DB.pacientes || []).forEach(patient => {
        const dateBase = patient.dataCadastro || patient.createdAt || getTodayISO();
        const year = getYearFromDate(dateBase);
        if (year !== currentYear) return;
        const month = getMonthFromDate(dateBase);
        novosPacientes[month] += 1;
    });

    if (financeChart) financeChart.destroy();
    if (patientsChart) patientsChart.destroy();

    financeChart = new Chart(financeCanvas.getContext('2d'), {
        type: 'bar',
        data: {
            labels,
            datasets: [
                {
                    label: 'Receitas',
                    data: receitas,
                    backgroundColor: 'rgba(111, 75, 54, 0.75)',
                    borderRadius: 10,
                    borderSkipped: false
                },
                {
                    label: 'Despesas',
                    data: despesas,
                    backgroundColor: 'rgba(203, 229, 247, 0.95)',
                    borderRadius: 10,
                    borderSkipped: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'top' }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: value => formatCurrency(value)
                    }
                }
            }
        }
    });

    patientsChart = new Chart(patientsCanvas.getContext('2d'), {
        type: 'line',
        data: {
            labels,
            datasets: [{
                label: 'Novos pacientes',
                data: novosPacientes,
                borderColor: '#6F4B36',
                backgroundColor: 'rgba(203, 229, 247, 0.35)',
                tension: 0.35,
                fill: true,
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });
}

function renderStrategySection() {
    renderStrategyTable();
    requestAnimationFrame(() => {
        requestAnimationFrame(() => {
            renderAnalytics();
        });
    });
}

// ============================================
// EXPORTS
// ============================================

window.exportFinancialExcel = () => { 
    const entries = getFilteredFinancialEntries();
    const rows = entries.map(item => ({
        Data: formatDate((item.data || '').split('T')[0]),
        Referencia: item.pacienteNome || item.origem || '—',
        Tipo: item.tipo,
        Valor: Number(item.valor || 0),
        Pagamento: item.metodo || item.origem || '—'
    }));
    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Financeiro');
    XLSX.writeFile(workbook, `financeiro_${financialFilterYear}_${financialFilterMode === 'month' ? String(financialFilterMonth + 1).padStart(2, '0') : 'anual'}.xlsx`);
};

window.exportFinancialPDF = () => { 
    const entries = getFilteredFinancialEntries();
    const { jsPDF } = window.jspdf || {};
    if (!jsPDF) {
        showToast('Biblioteca de PDF indisponível.', 'error');
        return;
    }

    const doc = new jsPDF();
    const periodLabel = financialFilterMode === 'month'
        ? `${String(financialFilterMonth + 1).padStart(2, '0')}/${financialFilterYear}`
        : `${financialFilterYear}`;

    doc.setFontSize(16);
    doc.text('Relatório Financeiro', 14, 16);
    doc.setFontSize(10);
    doc.text(`Período: ${periodLabel}`, 14, 23);

    const body = entries.map(item => [
        formatDate((item.data || '').split('T')[0]),
        item.pacienteNome || item.origem || '—',
        item.tipo,
        formatCurrency(Number(item.valor || 0)),
        item.metodo || item.origem || '—'
    ]);

    const receitas = entries.filter(f => Number(f.valor || 0) > 0).reduce((s,f) => s + Number(f.valor || 0), 0);
    const despesas = entries.filter(f => Number(f.valor || 0) < 0).reduce((s,f) => s + Math.abs(Number(f.valor || 0)), 0);
    const saldo = receitas - despesas;

    doc.autoTable({
        startY: 28,
        head: [['Data', 'Referência', 'Tipo', 'Valor', 'Pagamento']],
        body,
        styles: { fontSize: 9 },
        headStyles: { fillColor: [111, 75, 54] }
    });

    const finalY = doc.lastAutoTable ? doc.lastAutoTable.finalY + 10 : 40;
    doc.text(`Receitas: ${formatCurrency(receitas)}`, 14, finalY);
    doc.text(`Despesas: ${formatCurrency(despesas)}`, 14, finalY + 7);
    doc.text(`Saldo: ${formatCurrency(saldo)}`, 14, finalY + 14);

    doc.save(`financeiro_${periodLabel.replace('/', '-')}.pdf`);
};

window.exportConsolidatedExcel = () => { 
    showToast('Exportando lista consolidada...', 'success'); 
};

window.exportConsolidatedPDF = () => { 
    showToast('Exportando PDF...', 'success'); 
};

// ============================================
// VISUAL ENHANCEMENTS
// ============================================

function initVisualEnhancements() {
    // Cards
    document.querySelectorAll('.bg-white.rounded.shadow').forEach(el => {
        if (!el.classList.contains('card') && !el.classList.contains('kpi-card')) {
            el.classList.add('card');
        }
    });
    
    // Botões primários
    document.querySelectorAll('button.bg-blue-600, button.bg-indigo-600, button.bg-green-600, button.bg-purple-600').forEach(btn => {
        btn.classList.remove('bg-blue-600', 'bg-indigo-600', 'bg-green-600', 'bg-purple-600');
        btn.classList.add('btn-primary');
    });
    
    // Botões secundários
    document.querySelectorAll('button.bg-gray-200, button.border-gray-300, button.bg-gray-100').forEach(btn => {
        btn.classList.add('btn-secondary');
        btn.classList.remove('bg-gray-200', 'bg-gray-100');
    });
    
    // Navegação
    document.querySelectorAll('.nav-btn').forEach(nav => {
        nav.classList.remove('bg-white', 'border', 'rounded', 'shadow-sm', 'hover:bg-blue-50');
        nav.classList.add('nav-link');
    });
    
    // Ativar link ativo
    const activeSection = document.querySelector('main > section:not(.hidden)')?.id;
    document.querySelectorAll('.nav-link').forEach(nav => {
        nav.classList.remove('active');
        if (nav.getAttribute('onclick')?.includes(activeSection)) {
            nav.classList.add('active');
        }
    });
    
    // KPI Cards
    document.querySelectorAll('[id^="kpi-"]').forEach(el => {
        const card = el.closest('.p-6, .kpi-card');
        if (card && !card.classList.contains('kpi-card')) {
            card.classList.remove('p-6', 'bg-white', 'rounded-lg', 'shadow-md', 'border-l-4');
            card.classList.add('kpi-card');
            
            const valueEl = card.querySelector('.text-3xl');
            if (valueEl) {
                valueEl.classList.remove('text-3xl', 'text-gray-800');
                valueEl.classList.add('kpi-value');
            }
            
            const labelEl = card.querySelector('.text-sm.text-gray-500');
            if (labelEl) {
                labelEl.classList.remove('text-sm', 'text-gray-500');
                labelEl.classList.add('kpi-label');
            }
        }
    });
    
    // Tabelas
    document.querySelectorAll('.bg-white.rounded.shadow.overflow-hidden').forEach(tableWrapper => {
        if (!tableWrapper.classList.contains('table-container')) {
            tableWrapper.classList.remove('bg-white', 'rounded', 'shadow', 'overflow-hidden');
            tableWrapper.classList.add('table-container');
        }
    });
    
    // Títulos de seção
    const pageTitle = document.getElementById('page-title');
    if (pageTitle && !pageTitle.classList.contains('section-title')) {
        pageTitle.classList.remove('text-2xl', 'font-bold', 'text-gray-800', 'mb-6', 'border-b', 'pb-2');
        pageTitle.classList.add('section-title');
    }
}

// ============================================
// SIMULAÇÃO
// ============================================

function simulateUserFlow() {
    try {
        console.log('--- Iniciando simulação de uso ---');
        
        const today = new Date().toISOString().split('T')[0];
        
        // Criar agendamentos para hoje
        if (!DB.agendamentos.some(a => a.data === today && a.status !== 'Finalizado')) {
            const pacientesParaAgendar = ['3', '4', '5'];
            const horarios = ['09:00', '10:30', '14:00'];
            const tipos = ['Consulta', 'Retorno', 'Procedimento'];
            
            pacientesParaAgendar.forEach((pid, idx) => {
                const paciente = DB.pacientes.find(p => p.id === pid);
                if (paciente) {
                    DB.agendamentos.push({
                        id: 'ag_sim_' + idx + '_' + generateId(),
                        pacienteId: pid,
                        pacienteNome: paciente.nome,
                        data: today,
                        hora: horarios[idx % horarios.length],
                        motivo: tipos[idx % tipos.length],
                        tipo: tipos[idx % tipos.length],
                        valor: 150.00,
                        prioridade: idx === 0 ? 'Emergência' : 'Normal',
                        status: idx === 0 ? 'Aguardando' : 'Agendado',
                        sessoes: 1
                    });
                }
            });
            saveDB();
            console.log('Agendamentos de simulação criados');
        }
        
        renderCalendar();
        renderPacientes();
        renderAtendimentoScreen();
        
        // Iniciar atendimento automático
        const apptHoje = DB.agendamentos.find(a => a.data === today && a.status === 'Aguardando');
        if (apptHoje) {
            console.log('Iniciando atendimento automático para', apptHoje.pacienteNome);
            startConsultation(apptHoje.id);
            
            // Adicionar medicamentos e exames de exemplo
            if(DB.estoque && DB.estoque.length > 0) {
                tempPrescription.push({ 
                    id: DB.estoque[0].id, 
                    nome: DB.estoque[0].nome, 
                    qtd: 1, 
                    total: DB.estoque[0].preco 
                });
            }
            
            if(DB.catalogoExames && DB.catalogoExames.length > 0) {
                tempExams.push({ 
                    id: DB.catalogoExames[0].id, 
                    nome: DB.catalogoExames[0].nome, 
                    preco: DB.catalogoExames[0].preco 
                });
            }
            
            updateListsAndTotals();
        }
        
        console.log('--- Simulação finalizada ---');
    } catch (err) { 
        console.error('Erro na simulação:', err); 
    }
}

// ============================================
// INITIALIZATION
// ============================================

window.onload = async function() {
    await loadDB();
    document.getElementById('modal-login').classList.remove('hidden');
    renderCalendar();
    
    // Aplicar melhorias visuais
    setTimeout(() => {
        initVisualEnhancements();
    }, 100);
};

// Executar simulação se ativa
if (typeof SIMULATE_TESTS !== 'undefined' && SIMULATE_TESTS) {
    setTimeout(simulateUserFlow, 800);
};
// ============================================
// EXPORT GLOBAL FUNCTIONS
// ============================================

window.login = login;
window.logout = logout;
window.showSection = showSection;
window.openModal = openModal;
window.closeModal = closeModal;
window.resetSystem = resetSystem;
window.changeMonth = changeMonth;
window.goToToday = goToToday;
window.checkIn = checkIn;
window.startConsultation = startConsultation;
window.addMedicationToPrescription = addMedicationToPrescription;
window.addExamToConsultation = addExamToConsultation;
window.proceedToPayment = proceedToPayment;
window.confirmPayment = confirmPayment;
window.editPatient = editPatient;
window.editProtocol = editProtocol;
window.openPatientReport = openPatientReport;
window.renderPatientQuickReport = renderPatientQuickReport;
window.openFullReportFromQuick = openFullReportFromQuick;
window.openSellProtocolModal = openSellProtocolModal;
window.openAnamneseHistory = openAnamneseHistory;
window.viewAnamneseDetail = viewAnamneseDetail;
window.initVisualEnhancements = initVisualEnhancements;